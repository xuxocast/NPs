June 2015
 - [X] Add support for real orders by carefully coding the reflection formulae.
 - [ ] Add support for real arguments via a static cast
	from double to complex<double>.
 - [ ] Add support for spherical Bessel functions.
 - [ ] Test for more values of order and argument.
 - [ ] Add support for derivatives of spherical Bessel functions.
